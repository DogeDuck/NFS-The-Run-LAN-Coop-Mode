"""Resolve current launcher sessions for local or Radmin diagnosis. No auto launch."""
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
from coop_diagnostics import Reader

CLIENT_NAME='Need For Speed The Run.exe'
SERVER_NAME='NFSTR_Server.exe'
CLIENT_BUILDS={'95BA75BB168B2FFC38C4539E2287D8BE31DCC55D2001D53C7C7A60696C839F14','95BA75BB168B2FFC38C4539E2287D8BE31DCC55D2001D53C7C7A60696C839F14','C9D48E500EF82EFC642EDF2DB848A9072E56FBC114E283173D6E7E58BAC634A6',
               '2CB4570C34E46CC74CCDED44F8F38338C12A0EDFBB33A74572B72FC6E11AD249'}
SERVER_BUILDS={'4AFB76C21D08439778DBA038AD787618F752AA3C639A18A07A5B1672C0263C9D','4AFB76C21D08439778DBA038AD787618F752AA3C639A18A07A5B1672C0263C9D',
               'DCFAFC833016BAADE51F556C82963BA8C015406ADC69BEA0006919AD7DD68695',
               '79368D76F6967918C2AE0208757546AA5A0E197B8EE9BFDB631ED809F15AC79E',
               '22F1604CC40643DBCB18154CDA3DA627A63F0B34A4DFDFD7631AD99C9A81B768',
               '76F2D6DDDBBEAE3C6FDA85644C4D9D65ED7551AB6542AD4D08750EA4F2C04A92',
               '2BBD8E66B7E5219CF72C7CCCA06404AA2C36712F2B58E4CFEFCAA53C1082066C'}
DOTNET_FILETIME_EPOCH=504911232000000000

def default_session_path():
    directory=os.environ.get('LOCALAPPDATA')
    if not directory:raise ValueError('LOCALAPPDATA missing; use --session')
    return Path(directory)/'TheRunStoryCoop/active-session.json'

def select_targets(session):
    if session.get('Status')!='running':raise ValueError('Launcher session is not running')
    role=session.get('Role')
    if role not in ('Host','Guest'):raise ValueError('Unknown session role')
    game=PureWindowsPath(session['GameDirectory'])
    if not game.is_absolute() or any(p.upper()=='THERUNBACKUP' for p in game.parts):
        raise ValueError('Invalid game directory')
    result=[]
    specs=[('Client','HOST' if role=='Host' else 'GAST',CLIENT_NAME)]
    if role=='Host':specs.append(('Server','SERVER',SERVER_NAME))
    for key,label,name in specs:
        record=session.get(key)
        if not isinstance(record,dict):raise ValueError(f'Missing {key} process record')
        if type(record.get('Id')) is not int or record['Id']<=0:raise ValueError('Invalid PID')
        if type(record.get('StartTicks')) is not int or record['StartTicks']<=DOTNET_FILETIME_EPOCH:
            raise ValueError('Missing process creation time')
        expected=game/name
        if PureWindowsPath(record.get('Path',''))!=expected:raise ValueError('Process path does not match session game directory')
        result.append(dict(role=label,pid=record['Id'],path=str(expected),start_ticks=record['StartTicks']))
    if len({row['pid'] for row in result})!=len(result):raise ValueError('Duplicate PID')
    return result

def read_targets(path=None):
    return select_targets(json.loads((path or default_session_path()).read_text(encoding='utf-8-sig')))

def open_reader(target):
    allowed=SERVER_BUILDS if target['role']=='SERVER' else CLIENT_BUILDS
    digest=hashlib.sha256(Path(target['path']).read_bytes()).hexdigest().upper()
    if digest not in allowed:raise ValueError('Unsupported executable build')
    reader=Reader(target['pid'],Path(target['path']))
    try:
        if reader.creation_time()+DOTNET_FILETIME_EPOCH!=target['start_ticks']:
            raise ValueError('PID was reused or process creation time changed')
        return reader,digest
    except BaseException:
        reader.close();raise
